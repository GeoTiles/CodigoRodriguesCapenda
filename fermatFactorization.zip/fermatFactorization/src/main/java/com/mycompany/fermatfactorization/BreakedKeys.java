/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fermatfactorization;

import java.math.BigInteger;
import java.time.Duration;
import java.util.ArrayList;

/**
 *
 * @author rcapenda
 */
public class BreakedKeys {

    private static Duration durationTime;
    private static BigInteger n, p, q;
    private static String numberOfBits;

    public static Duration getDurationTime() {
        return durationTime;
    }

    public static void setDurationTime(Duration durationTime) {
        BreakedKeys.durationTime = durationTime;
    }

    public static BigInteger getN() {
        return n;
    }

    public static void setN(BigInteger n) {
        BreakedKeys.n = n;
    }

    public static BigInteger getP() {
        return p;
    }

    public static void setP(BigInteger p) {
        BreakedKeys.p = p;
    }

    public static BigInteger getQ() {
        return q;
    }

    public static void setQ(BigInteger q) {
        BreakedKeys.q = q;
    }

    public static String getNumberOfBits() {
        return numberOfBits;
    }

    public static void setNumberOfBits(String numberOfBits) {
        BreakedKeys.numberOfBits = numberOfBits;
    }

    public BreakedKeys(Duration durationTime,
            BigInteger n, BigInteger p, BigInteger q,
            String numberOfBits) {
        this.durationTime = durationTime;
        this.n = n;
        this.p = p;
        this.q = q;
        this.numberOfBits = numberOfBits;
    }

    public BreakedKeys() {
    }
    
    

}
