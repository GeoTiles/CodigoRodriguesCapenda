/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fermatfactorization;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rcapenda
 */
public class MyFiles {

    private static ArrayList<String> KeysFile = new ArrayList<>();
    private static ArrayList<BigInteger> publicKeys = new ArrayList<>();

    public static ArrayList<BigInteger> getPublickeys() {
        return publicKeys;
    }

    private static void recordResults(ArrayList<BreakedKeys> records, String fileName) throws IOException {
      

            File myFile = new File(fileName);
            FileOutputStream fos = new FileOutputStream(myFile);
            FileWriter myWriter = new FileWriter(fileName);
            BufferedWriter bWriter = new BufferedWriter(new OutputStreamWriter(fos));

            if (myFile.createNewFile()) {
                //FileReader myReader = new FileReader(fileName);
                records.forEach(action -> {
                    try {
                        bWriter.write("Testes");
                    } catch (IOException ex) {
                        Logger.getLogger(MyFiles.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        bWriter.newLine();
                    } catch (IOException ex) {
                        Logger.getLogger(MyFiles.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        myWriter.write("Testesteste");
                    } catch (IOException ex) {
                        Logger.getLogger(MyFiles.class.getName()).log(Level.SEVERE, null, ex);
                    }
 /*                   System.out.println(action.getNumberOfBits().toString() + "," + action.getN().toString()
                            + "," + action.getP().toString() + "," + action.getQ().toString()
                            + "," + action.getDurationTime().toString());
*/
                    try {
                        bWriter.newLine();
                    } catch (IOException ex) {
                        Logger.getLogger(MyFiles.class.getName()).log(Level.SEVERE, null, ex);
                    }

                });

            }
    }

    

    static ArrayList<String> setPublickeys(String fileName) {

        try {

            File myObj = new File(fileName);
            if (!myObj.createNewFile()) {
                //FileReader myReader = new FileReader("primes.txt");
                Scanner myReader = new Scanner(new FileReader(fileName));
                //Moving to the file last line
                try {
                    while (myReader.hasNextLine()) {
                        KeysFile.add(myReader.nextLine());
                    }
                    myReader.close();
                } catch (NullPointerException e) {
                    System.out.println("Erro na linha  ");
                }
                return KeysFile;
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
        return null;
    }

    public static ArrayList<String> getKeysFile() {
        return KeysFile;
    }

    public static ArrayList<BigInteger> getPublicKeys() {
        return publicKeys;
    }

    public MyFiles() {
    }

}
