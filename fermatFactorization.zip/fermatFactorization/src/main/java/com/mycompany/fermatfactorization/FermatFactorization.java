/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.fermatfactorization;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author rcapenda
 */
public class FermatFactorization {

    private static ArrayList<Duration> breakingTime = new ArrayList<>();
    private static ArrayList<BreakedKeys> breakingData;

    private static BreakedKeys FermatAlgorithm(BigInteger n, String numOfBit) {
        Duration duration = Duration.ZERO;
        LocalTime end, begin;
        BigInteger x = new BigInteger("0"),
                y = new BigInteger("0"), aux = new BigInteger("0");
        if (n.mod(BigInteger.valueOf(2)).compareTo(BigInteger.valueOf(0)) == 0) {
            System.out.println("Invalide value fo n \n n must be odd");
        } else {
            begin = LocalTime.now();
            x = n.sqrt().add(BigInteger.valueOf(1));
            aux = x.pow(2).subtract(n);
            y = aux.sqrt();
            //System.out.println("X = " + x + "  y =  " + y);

            while ((y.pow(2).compareTo(aux) != 0) && (x.compareTo(n) < 0)) {
                x = x.add(BigInteger.valueOf(1));
                aux = x.pow(2).subtract(n);
                y = aux.sqrt();
            }
            //System.out.println("Factor:   " + x.subtract(y));
            end = LocalTime.now();
            duration = Duration.between(begin, end);

        }
        BreakedKeys dataAux = new BreakedKeys(duration, n, x.add(y),
                x.subtract(y), numOfBit);
        return dataAux;
    }

    ;

    public static void main(String[] args) throws IOException {
        breakingData = new ArrayList<>();
        String fileName = "saida.csv";
        BreakedKeys dataAux;
        if (args.length < 2) {
            System.out.println("java -jar fermatFactorization-1.0-SNAPSHOT.jar"
                    + " <ficheiro_de_chave.csv>"
                    + " <ficheiro_de_saida.csv> \n\n");
        } else {
            try {
            File outputFile = new File(args[1]);
            outputFile.createNewFile();
            if (!outputFile.createNewFile()) {
                try {
                    FileWriter myWriter = new FileWriter(args[1]);

                    for (String action : MyFiles.setPublickeys(args[0])) {
                        String[] aux = action.split(",");
                        dataAux=(FermatAlgorithm(new BigInteger(aux[2]), aux[0]));
                        myWriter.write(dataAux.getNumberOfBits()+","+dataAux.getN()+"," +dataAux.getP()+
                                ","+dataAux.getQ()+","+dataAux.getDurationTime()+"\n");
                    }
                    
                    myWriter.close();
                } catch (IOException e) {
                }
            } else {
                System.out.println("O Sistema não conseguiu criar "
                        + "o ficheiro indicado");
            }
        } catch (IOException e) {
        }

        }
    }
}
