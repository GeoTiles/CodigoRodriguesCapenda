/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.primalitytest;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.time.Duration;
import java.time.LocalTime;

/**
 *
 * @author rcapenda
 */
public class PrimalityTest {

    static boolean FermatPrimalityTest(BigInteger n) {
        BigInteger aux, count = new BigInteger("0");
        BigInteger i = new BigInteger("1");
        for (; i.compareTo(n) <= 0; i = i.add(BigInteger.valueOf(1))) {
            if (i.pow((int) n.doubleValue()).subtract(i).mod(n).
                    compareTo(BigInteger.valueOf(0)) != 0) {
                return false;
            }
        }
        return true;
    }

    static boolean MillerRabinPrimalityTest(int n) {
        if (n % 2 != 0) {
            int k = 0, m, nAux;
            BigInteger power;
            double exp;
            nAux = n - 1;
            while (nAux % 2 == 0) {
                k++;
                nAux = nAux / 2;
            }
            //select a base 1<b<n-1
            // m = (int)(Math.random() * (n-3)) +2;
            m = 2;
            for (int j = 2; j < k; j++) {
                exp = Math.pow(2, j) * nAux;
                power = BigInteger.valueOf(m).pow((int) exp);
                if (power.mod(BigInteger.valueOf(n)).compareTo(BigInteger.
                        valueOf(-1)) == 0) {
                    return true;
                }
            }
            exp = Math.pow(2, k) * nAux;
            power = BigInteger.valueOf(m).pow((int) exp);
            return power.mod(BigInteger.valueOf(n)).compareTo(BigInteger.
                    valueOf(1)) == 0;
        } else {
            return false;
        }
    }
    
    
    public static void main(String[] args) {
        Duration duration = Duration.ZERO;
        LocalTime end, begin;
        if (args.length < 2) {
            System.out.println("java -jar FermatPrimalityTest-1.0-SNAPSHOT.jar"
                    + " <ficheiro_inteiros.txt>"
                    + " <ficheiro_de_saida.csv> \n\n");
        } else {
            
            try {
                File outputFile = new File(args[1]);
                outputFile.createNewFile();
                if (!outputFile.createNewFile()) {
                    try {
                        FileWriter myWriter = new FileWriter(args[1]);

                        for (String action : MyFiles.setNumbers(args[0])) {
                                begin =  begin = LocalTime.now();
                            if (FermatPrimalityTest(new BigInteger(action))) {
                                end =  begin = LocalTime.now();
                                duration = Duration.between(begin, end);
                                myWriter.write(action + "," + "Primo" +","+duration + "\n");
                            } else {
                                myWriter.write(action + "," + "N Primo"+","+duration +"\n");
                            }
                        }

                        myWriter.close();
                    } catch (IOException e) {
                    }
                } else {
                    System.out.println("O Sistema não conseguiu criar "
                            + "o ficheiro indicado");
                }
            } catch (IOException e) {
            }

        }
    }
}
