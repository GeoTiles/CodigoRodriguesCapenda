/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.millerrabinprimalitytest;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.time.Duration;
import java.time.LocalTime;

/**
 *
 * @author rcapenda
 */
public class MillerRabinPrimalityTest {

    static boolean MillerRabinPrimalityTest(BigInteger n) {
        if (n.mod(BigInteger.TWO).compareTo(BigInteger.ONE) != 0) {
            int k = 0, m;
            BigInteger power, nAux;
            double exp;
            nAux = n.subtract(BigInteger.valueOf(1));
            while (nAux.mod(BigInteger.valueOf(2)).compareTo(BigInteger.ZERO) == 0) {
                k++;
                nAux = nAux.divide(BigInteger.TWO);
            }
            //select a base 1<b<n-1
            // m = (int)(Math.random() * (n-3)) +2;
            m = 2;
            Double test;
            for (int j = 2; j < k; j++) {
                test = Math.pow(2, j);
                exp = nAux.multiply(new BigInteger(test.toString())).doubleValue();
                power = BigInteger.valueOf(m).pow((int) exp);
                if (power.mod(n).compareTo(BigInteger.valueOf(-1)) == 0) {
                    return true;
                }
            }
            test = Math.pow(2, k);
            exp =  nAux.multiply(new BigInteger(test.toString())).doubleValue();
            power = BigInteger.valueOf(m).pow((int) exp);
            return power.mod(n).compareTo(BigInteger.ONE) == 0;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        Duration duration = Duration.ZERO;
        LocalTime end, begin;
        if (args.length < 2) {
            System.out.println("java -jar FermatPrimalityTest-1.0-SNAPSHOT.jar"
                    + " <ficheiro_inteiros.txt>"
                    + " <ficheiro_de_saida.csv> \n\n");
        } else {

            try {
                File outputFile = new File(args[1]);
                outputFile.createNewFile();
                if (!outputFile.createNewFile()) {
                    try {
                        FileWriter myWriter = new FileWriter(args[1]);

                        for (String action : MyFiles.setNumbers(args[0])) {
                            begin = LocalTime.now();
                            if (MillerRabinPrimalityTest(new BigInteger(action))) {
                                end = begin = LocalTime.now();
                                duration = Duration.between(begin, end);
                                myWriter.write(action + "," + "Primo" + "," + duration + "\n");
                            } else {
                                myWriter.write(action + "," + "N Primo" + "," + duration + "\n");
                            }
                        }

                        myWriter.close();
                    } catch (IOException e) {
                    }
                } else {
                    System.out.println("O Sistema não conseguiu criar "
                            + "o ficheiro indicado");
                }
            } catch (IOException e) {
            }

        }
    }
}

