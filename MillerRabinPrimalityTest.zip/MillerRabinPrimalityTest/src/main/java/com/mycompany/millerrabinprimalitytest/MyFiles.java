/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.millerrabinprimalitytest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rcapenda
 */
public class MyFiles {

    private static ArrayList<String> KeysFile = new ArrayList<>();
    private static ArrayList<BigInteger> publicKeys = new ArrayList<>();

    public static ArrayList<BigInteger> getPublickeys() {
        return publicKeys;
    }

    
    static ArrayList<String> setNumbers(String fileName) {

        try {

            File myObj = new File(fileName);
            if (!myObj.createNewFile()) {
                //FileReader myReader = new FileReader("primes.txt");
                Scanner myReader = new Scanner(new FileReader(fileName));
                //Moving to the file last line
                try {
                    while (myReader.hasNextLine()) {
                        KeysFile.add(myReader.nextLine());
                    }
                    myReader.close();
                } catch (NullPointerException e) {
                    System.out.println("Erro na linha  ");
                }
                return KeysFile;
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
        }
        return null;
    }

    public static ArrayList<String> getKeysFile() {
        return KeysFile;
    }

    public static ArrayList<BigInteger> getPublicKeys() {
        return publicKeys;
    }

    public MyFiles() {
    }

}
